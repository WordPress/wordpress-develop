=== DigiSell FSE ===
Contributors: gracethemes
Tags:blog, photography, entertainment, one-column, two-columns, left-sidebar, right-sidebar, 
block-patterns, block-styles, custom-colors, editor-style, custom-background, custom-logo, 
custom-menu, featured-images, footer-widgets, full-site-editing, block-patterns,  threaded-comments, 
wide-blocks, translation-ready
Requires at least: 5.0
Requires PHP:  5.6
Tested up to: 6.0
License: GNU General Public License version 2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
DigiSell FSE is a elegant, highly attractive, sofisticated, responsive and the best free marketing agency WordPress theme. DigiSell FSE is one such option for website owners who are into eCommerce, auto dealerships, bars and restaurants, hotels or hospitality, law firms, the medical sector, construction industries, or marketing. This theme is the best option in every aspect and can fulfil your needs to make a fully functional digital marketing website for your business. DigiSell FSE is a translation-ready and multilingual-friendly WordPress theme, and your customers can easily interpret your website and its offerings. This free marketing agency WordPress theme is SEO-friendly. In short, you will always rank higher when you use this theme. This theme is very easy to use, and even a neophyte user can use it without any assistance. This theme comes with precise documentation that makes execution super smooth. This free marketing agency WordPress theme is adaptable, and you can access every feature of this theme hassle-freely. As you do not need any technical assistance, it saves a lot of money for you.

== Theme License & Copyright == 

* DigiSell FSE WordPress Theme, Copyright 2023 Grace Themes 
* DigiSell FSE is distributed under the terms of the GNU GPL

== Changelog ==

= 1.0 =
* Initial version release

= 1.1 =
* Removed customizer register functions



== Resources ==

Theme is Built using the following resource bundles.

= jQuery Nivo Slider =
* Name of Author: Dev7studios
* Copyright: 2010-2012
* https://github.com/Codeinwp/Nivo-Slider-jQuery
* License: MIT License
* https://github.com/Codeinwp/Nivo-Slider-jQuery/blob/master/license.txt

= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/1629588 (Frontpage banner image)

= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/818671 (inner banner)

     
For any help you can mail us at support@gracethemes.com