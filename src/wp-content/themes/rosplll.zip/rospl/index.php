<?php
include('header.php');
?>

<main>
    <h1>Welcome to My PHP Project</h1>
    <p>This is the homepage of my PHP project.</p>
</main>

<?php
include('footer.php');
?>
