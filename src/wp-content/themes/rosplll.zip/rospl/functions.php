my_php_project/
│
├── index.php
├── style.css
├── header.php
├── footer.php
└── functions.php
