<footer>
        <p>&copy; <?php echo date('Y'); ?> My PHP Project</p>
    </footer>
</body>
</html>
