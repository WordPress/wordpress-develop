<?php
/**
 * The right sidebar template
 *
 *
 * @package Customizr
 * @since Customizr 3.1.0
 */
czr_fn_render_template(
  'content/sidebars/right_sidebar',
   array( 'model_class' => 'content/sidebars/sidebar' )
);
