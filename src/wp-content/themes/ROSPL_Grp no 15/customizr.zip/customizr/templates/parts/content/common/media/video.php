<?php
/**
 * The template for displaying a video media
 *
 *
 * @package Customizr
 */
?>
<div class="video-container <?php czr_fn_echo( 'element_class' ) ?>" <?php czr_fn_echo( 'element_attributes' ) ?>>
  <?php czr_fn_echo( 'video' ) ?>
</div>