<?php
/**
 * The template for displaying the back to top arrow button
 *
 * @package Customizr
 * @since Customizr 3.5.0
 */
?>
<button class="btn czr-btt czr-btta <?php czr_fn_echo('element_class') ?>" <?php czr_fn_echo('element_attributes') ?>><i class="icn-up-small"></i></button>
