<?php
/**
 * The template for displaying the social links block
 */
?>
<ul class="socials <?php czr_fn_echo('element_class') ?>" <?php czr_fn_echo('element_attributes') ?>>
  <?php czr_fn_echo( 'socials' ) ?>
</ul>
