<?php
/**
 * Plugin Name: E2E Test Plugin
 * Version: 2.0
 * Update URI: false
 */
