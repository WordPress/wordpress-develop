<?php
/**
 * Plugin Name: E2E Test Plugin
 * Version: 1.0
 * Update URI: false
 */
