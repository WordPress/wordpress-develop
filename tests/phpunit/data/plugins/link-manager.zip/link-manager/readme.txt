=== Link Manager ===
Contributors: nacin
Tags: links, link manager, blogroll
Requires at least: 3.5
Tested up to: 3.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Enables the Link Manager that existed in WordPress until version 3.5.

== Description ==

In WordPress 3.5, the Link Manager (which some use to build blogrolls) will
be disabled by default. If you have links when you update, it'll still be there.
But you can use this plugin to ensure it will always be there, even if you
update to a later version of WordPress or remove all of your current links.
