<?php

/**
 * Plugin Name: Archive Nautilus Broken
 * Plugin URI: https://core.trac.wordpress.org/ticket/60398
 * Description: A test plugin for the WP zip issue. Archived on Ubuntu 20.04.6 with Nautilus 3.36.3-stable
 * Author: svitlana41319
 * Author URI: https://profiles.wordpress.org/svitlana41319/
 * Version: 0.0.1
 * Requires at least: 6.2.2
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.txt
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit();
}

